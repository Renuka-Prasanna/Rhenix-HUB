import 'package:precision_hub/screens/Code/company.dart';
import 'package:precision_hub/screens/Code/company2.dart';
import 'package:precision_hub/screens/Code/signUp.dart';

class AppRoutes {
  static const companyScreen = "/companyScreen";
  static const companyScreen2 = "/companyScreen2";
  static const signUp = "/signUp";
}
