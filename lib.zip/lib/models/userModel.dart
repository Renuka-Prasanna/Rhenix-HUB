class UserData {
  String usersPhone;
  String fullName;
  String email;
  String zipCode;
  String gender;
  UserData(this.usersPhone, this.fullName, this.email, this.zipCode, this.gender);
}

class UserAdditionalInfo {
  String feet;
  String inch;
  String meter;
  String cm;
  String weight;
  String heighUnit;
  String weightUnit;
  UserAdditionalInfo(this.feet, this.inch, this.meter, this.cm, this.weight, this.heighUnit, this.weightUnit);
}
