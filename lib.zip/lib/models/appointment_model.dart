class Appointment {
  String doctorName;
  String appointmentDate;
  String appointmentTime;
  Appointment(this.doctorName, this.appointmentDate, this.appointmentTime);
}
