class Vitals {
  String systolic;
  String diastolic;
  String sugarLevel;
  String heartRate;
  String vitalDate;
  String vitalTime;
  Vitals(this.systolic, this.diastolic, this.sugarLevel, this.heartRate, this.vitalDate, this.vitalTime);
}
