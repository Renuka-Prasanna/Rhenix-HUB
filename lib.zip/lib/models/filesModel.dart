class Files {
  String name;
  String extension;
  String userphone;
  String dateTime;
  Files(this.name, this.extension, this.userphone, this.dateTime);
}
