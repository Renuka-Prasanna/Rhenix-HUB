class DoctorInfo {
  String doctorName;
  String speciality;
  String doctorImg;
  DoctorInfo(this.doctorName, this.speciality, this.doctorImg);
}
