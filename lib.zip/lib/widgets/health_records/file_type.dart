enum FileType {
  jpg,
  png,
  jpeg,
  doc,
  pdf,
  other,
  ics,
}
