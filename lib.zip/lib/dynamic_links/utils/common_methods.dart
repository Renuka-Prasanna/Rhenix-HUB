import 'package:flutter/material.dart';
import 'package:precision_hub/dynamic_links/ui/home_screen.dart';

Widget navigateToNextScreen() {
  return HomeScreen();
}
