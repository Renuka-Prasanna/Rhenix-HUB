// class ConsoleLogUtils {
//   static Function printLog(dynamic printMessage) {
//     print(printMessage);
//   }
  
// }
